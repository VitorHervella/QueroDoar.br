<html>
<body>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<header>
<link rel="stylesheet" type="text/css" href="page.css" />
<link rel="stylesheet" type="text/css" href="page2.css" />
<link rel="stylesheet" type="text/css" href="cadastro2.css" />
<table = "tablet" width="10%!">
			<tr>						
			<td><h2 class = "cps"><a href = "page.html"><div class = "button">Home</div></a></h2></td>			
			</tr>
</table>
</header>
<div id = "text"></br>
Cadastro -  Entidade
</br>
</div>
<div id= "fundo">
</div>
<div id="form2">
	<form action="bd_insere_entidade.php" method="post">

		<table id = "tablet3">
		
		
		<div class = "part1">
			<tr><td><b>Nome da Entidade</b></td><td><input class = "camp" type="text" name="nomeEntidade" maxlength="50" size="50"/><br/></td></tr>
			<tr><td><b>Nome Fantasia</b></td><td><input class = "camp" type="text" name="nomeFantasia" maxlength="50" size="50"/><br/></td></tr>
			<tr><td><b>Ramo da Entidade</b></td><td><input class = "camp" type="text" name="ramoEntidade" maxlength="50" size="50"/><br/></td></tr>
			<tr><td><b>CNPJ</b><td><input class = "camp" type="text" name="cnpj" maxlength="50" size="15"/>
			<tr><td><b>Inscrição Estadual</b></td><td><input class = "camp" type="text" name="inscricaoEstadual" maxlength="50" size="50"/><br/></td></tr>
			<tr><td><b>Inscrição Municipal</b></td><td><input class = "camp" type="text" name="inscricaoMunicipal" maxlength="50" size="50"/><br/></td></tr>
			
				
		</div>	
		
		
		
		
		
		<div class = "part4">
			<tr><td><b>Cidade</b><td><input class = "camp" type="text" name="cidade"  size="21"/>
			<b>Estado </b><select name="estado"> 
			<option value="estado">Estado</option> 
			<option value="ac">AC</option> 
			<option value="al">AL</option> 
			<option value="am">AM</option> 
			<option value="ap">AP</option> 
			<option value="ba">BA</option> 
			<option value="ce">CE</option> 
			<option value="df">DF</option> 
			<option value="es">ES</option> 
			<option value="go">GO</option> 
			<option value="ma">MA</option> 
			<option value="mt">MT</option> 
			<option value="ms">MS</option> 
			<option value="mg">MG</option> 
			<option value="pa">PA</option> 
			<option value="pb">PB</option> 
			<option value="pr">PR</option> 
			<option value="pe">PE</option> 
			<option value="pi">PI</option> 
			<option value="rj">RJ</option> 
			<option value="rn">RN</option> 
			<option value="ro">RO</option> 
			<option value="rs">RS</option> 
			<option value="rr">RR</option> 
			<option value="sc">SC</option> 
			<option value="se">SE</option> 
			<option value="sp">SP</option> 
			<option value="to">TO</option> 
			</select><br/></td></tr>	
		</div>
		
		<div class = "part5">
			<tr><td><b>CEP</b><td><input class = "camp" type="text" name="cep"  size="10"/>
			<b>Bairro <b><input class = "camp" type="text" name="bairro"  size="28"/><br/></td></tr>
			<tr><td><b>Endereço</b><td><input class = "camp" type="text" name="endereco"  size="30"/>
			<b>Numero</b><input class = "camp" type="text" name="numero"  size="7"/><br/></td></tr>
			<tr><td><b>Complemento </b><td><input class = "camp" type="text" name="complemento"  size="50"/><br/></td></tr>
			<tr><td><b>Website</b><td><input class = "camp" type="text" name="website"  size="50"/><br/></td></tr>
		</div>
		
		<div class = "part6">	
			<tr><td><b>Telefone</b><td><input class = "camp" type="text" name="telefone"  size="19"/>
			<b>Celular </b><input class = "camp" type="text" name="celular"  size="18"/><br/></td></tr>
		</div>
		
		<div class = "part7">
		<tr><td><b>Nome do Representante</b></td><td><input class = "camp" type="text" name="nomeRepresentante" maxlength="50" size="50"/><br/></td></tr>
			
			<tr><td><b>CPF do Representante</b></td><td><input class = "camp" type="text" name="cpfRepresentante" maxlength="50" size="50"/><br/></td></tr>
			<tr><td><b>Cargo do Representante</b></td><td><input class = "camp" type="text" name="cargoRepresentante" maxlength="50" size="50"/><br/></td></tr>
			<tr><td><b>D. Nascimento do Representante</b><td><input class = "camp" type="text" name="dataNascimentoRepresentante" maxlength="50" size="15"/>
			
			
			<tr><td><b>Email</b><td><input class = "camp" type="text" name="email"  size="50"/><br/></td></tr>
			<tr><td><b>Senha</b><td><input class = "camp" type="password" name="senha" maxlength ="9" size="50"/><br/></td></tr>
			<tr><td><b>Repetir senha</b><td><input class = "camp" type="password" name="repetirSenha" maxlength ="9" size="50"/><br/></td></tr>
		
			
				
		</div>
		
		
			
		</table>
		<tr><td rowspan='2' align='center' id = "submit"><input class = "but3" type="submit" value="Envia"/></td></tr>
		</form>
</div>
</body>
</html>