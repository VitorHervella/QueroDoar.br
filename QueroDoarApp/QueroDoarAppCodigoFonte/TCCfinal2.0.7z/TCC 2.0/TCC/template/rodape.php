<?php
	mysqli_close($db);
?>
</div><!--/content-->
		<div id="footer">
			<h2>Rodape</h2>
		</div>
		</DIV>	
	</BODY>
</HTML>