<HTML>
	<HEAD>
		<TITLE>Cadastro de Viagens</TITLE>
		<LINK rel="stylesheet" HREF="css/modelo.CSS" type="text/css"/>
	</HEAD>
	<BODY>
		<DIV id="TOPO">
			<table><tr>
				<td><img src="imagem/imagem.jpg" width="200" height="100"></td>
				<td><h1>Cadastrando Mensagens</h1></td>
			</tr></table>	
		</DIV>
		<?php
			include "template/menu.php";
			include "conexao/conecta.php";
		?>
	</BODY>
</HTML>