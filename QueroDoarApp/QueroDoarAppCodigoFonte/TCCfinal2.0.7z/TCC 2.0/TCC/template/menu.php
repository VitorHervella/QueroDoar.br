		<DIV id="BARRALATERAL">
			<UL>
				<LI> <a href= "index.php">Inicio</a> </LI>
				<LI> <a href= "form_cadastra.php">Cadastrar Mensagens</a> </LI>
				<LI> <a href= "form_pesquisa1.php">Consultar Mensagens</a> </LI>
			</UL>
		</DIV>
		<DIV id="CONTEUDO">