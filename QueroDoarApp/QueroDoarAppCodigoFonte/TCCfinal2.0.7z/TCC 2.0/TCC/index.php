<?php
	include "template/topo.php";
	
		  echo "<h3>Bem - Vindo ao site de Comentarios Turisticos</h3>";

	include "template/rodape.php";
?>