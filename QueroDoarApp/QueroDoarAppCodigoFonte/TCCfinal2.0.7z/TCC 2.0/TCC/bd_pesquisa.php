﻿<?php
	include "template/topo.php";
		
		  // Variaveis de formulário
		  $criterio=$_POST['criterio'];
		  $chave=$_POST['chave'];
		  $chave = trim($chave);
		  if (!$criterio || !$chave)
		  {
			 echo 'Impossivel realizar consulta, faltam dados!';
			 exit;
		  }
		  $criterio = addslashes($criterio);
		  $chave = addslashes($chave);
		  $query = "select * from tb_pessoafisica where ".$criterio." like '%".$chave."%'";
		  $result = mysqli_query($db,$query);
		  $num_results = mysqli_num_rows($result);
		  echo '<p>Número de Comentarios encontrados: '.$num_results.'</p>';
		  for ($i=0; $i <$num_results; $i++)
		  {
			 $row = mysqli_fetch_array($result);
			 echo '<br />Nome: ';
			 echo stripslashes($row[1]);
			 echo '<br />DataNascimento: ';
			 echo stripslashes($row[2]);
			 echo '<br />Sexo: ';
			 echo stripslashes($row[3]);
			 echo '<br />Email: ';
			 echo stripslashes($row[4]);
			 echo '<br />RG: ';
			 echo stripslashes($row[5]);
			 echo '<br />CPF: ';
			 echo stripslashes($row[6]);
			 echo '<br />Endereco: ';
			 echo stripslashes($row[7]);
			 echo '<br />Bairro: ';
			 echo stripslashes($row[8]);
			 echo '<br />Numero: ';
			 echo stripslashes($row[9]);
			 echo '<br />Complemento: ';
			 echo stripslashes($row[10]);
			 echo '<br />CEP: ';
			 echo stripslashes($row[11]);
			 echo '<br />Cidade: ';
			 echo stripslashes($row[12]);
			 echo '<br />Estado: ';
			 echo stripslashes($row[13]);
			 echo '<br />Telefone: ';
			 echo stripslashes($row[14]);
			 echo '<br />Celular: ';
			 echo stripslashes($row[15]);
		  }
		  
	include "template/rodape.php";
		  
?>