<?php
	include "template/topo.php";
?>
		<form action="bd_inseremensagem.php" method="post">
		<table>
			<tr><td><b>Nome</b></td><td><input type="text" name="nome" maxlength="50" size="50"/><br/></td></tr>
			<tr><td><b>D. Nascimento</b><td><input type="text" name="dataNascimento" maxlength="50" size="50"/><br/></td></tr>
			<tr><td><b>Sexo</b><td><input type="text" name="sexo"  size="50"/><br/></td></tr>
			<tr><td><b>Email</b><td><input type="text" name="email"  size="50"/><br/></td></tr>
			<tr><td><b>Senha</b><td><input type="text" name="senha"  size="50"/><br/></td></tr>
			<tr><td><b>Repetir senha</b><td><input type="text" name="repetirSenha"  size="50"/><br/></td></tr>
			<tr><td><b>RG</b><td><input type="text" name="rg"  size="50"/><br/></td></tr>
			<tr><td><b>CPF</b><td><input type="text" name="cpf"  size="50"/><br/></td></tr>
			<tr><td><b>Endereço</b><td><input type="text" name="endereco"  size="50"/><br/></td></tr>
			<tr><td><b>Bairro</b><td><input type="text" name="bairro"  size="50"/><br/></td></tr>
			<tr><td><b>Numero</b><td><input type="text" name="numero"  size="50"/><br/></td></tr>
			<tr><td><b>Complemento</b><td><input type="text" name="complemento"  size="50"/><br/></td></tr>
			<tr><td><b>CEP</b><td><input type="text" name="cep"  size="50"/><br/></td></tr>
			<tr><td><b>Cidade</b><td><input type="text" name="cidade"  size="50"/><br/></td></tr>
			<tr><td><b>Estado</b><td><input type="text" name="estado"  size="50"/><br/></td></tr>
			<tr><td><b>Telefone</b><td><input type="text" name="telefone"  size="50"/><br/></td></tr>
			<tr><td><b>Celular</b><td><input type="text" name="celular"  size="50"/><br/></td></tr>
			<tr><td rowspan='2' align='center'><input type="submit" value="Envia"/></td></tr>
		</table>
		</form>
<?php
	include "template/rodape.php";
?>