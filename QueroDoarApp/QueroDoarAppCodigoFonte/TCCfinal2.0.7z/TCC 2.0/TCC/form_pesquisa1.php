<?php
	include "template/topo.php";
?>
			<form action="bd_pesquisa.php" method="post">
			<table>
			<tr><td>Selecione um criterio: </td>
				<td><select name="criterio">
				  <option value="nome">Nome</option>
				  <option value="cidade">Cidade</option>
				  <option value="interesse">Interesse</option>
				</select><br/></td></tr>
				<tr><td>Digite o valor de busca:</td>
				<td><input name="chave" type="text"><br/></td></tr>
				<tr><td><input type="submit" value="Envia"></td></tr>
			</table>
			</form>
<?php
	include "template/rodape.php";
?>