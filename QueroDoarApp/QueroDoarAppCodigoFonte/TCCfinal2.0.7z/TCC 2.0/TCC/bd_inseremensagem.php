﻿<?php
	include "template/topo.php";
	
		  // RECEBE VARIAVEIS
		  $nome = $_POST['nome'];
		  $dataNascimento = $_POST['dataNascimento'];
		  $sexo = $_POST['sexo'];
		  $email = $_POST['email'];
		  $senha = $_POST['senha'];
		  $repetirSenha = $_POST['repetirSenha'];
		  $rg = $_POST['rg'];
		  $cpf = $_POST['cpf'];
		  $endereco = $_POST['endereco'];
		  $bairro = $_POST['bairro'];
		  $numero = $_POST['numero'];
		  $complemento = $_POST['complemento'];
		  $cep = $_POST['cep'];
		  $cidade = $_POST['cidade'];
		  $estado = $_POST['estado'];
		  $telefone = $_POST['telefone'];
		  $celular = $_POST['celular'];
		  
		  
		  if (!$nome || !$dataNascimento || !$sexo || !$email || !$senha || !$repetirSenha || !$rg || !$cpf || !$endereco || !$bairro || !$numero || !$complemento || !$cep || !$cidade || !$estado || !$telefone || !$celular)
		  {
			 echo 'voce não preencheu todos os dados<br />';
			 exit;
		  }
		  
		  //inserindo dados do formulario no bd
		  $query = "insert into tb_pessoafisica values (null,'$nome', '$dataNascimento', '$sexo', '$email', '$senha', '$repetirSenha', '$rg', '$cpf', '$endereco', '$bairro', '$numero', '$complemento', '$cep', '$cidade', '$estado', '$telefone', '$celular')";
		  $result = mysqli_query($db,$query);
		  if ($result)
			   echo  mysqli_affected_rows($db).' Comentario inserido com sucesso.</br>'; 
		  else echo mysqli_error($db).'<br>';
	
	include "template/rodape.php";
?>