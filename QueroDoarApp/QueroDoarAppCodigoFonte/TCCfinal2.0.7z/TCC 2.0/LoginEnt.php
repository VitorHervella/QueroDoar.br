<?php
session_start();

	include "conecta.php";

	$email = $_POST['email'];
	$senha = $_POST['senha'];
	
	if(!$email || !$senha){
		die("Faltam dados: Usuário e/ou senha");
	}
	@ $db = mysqli_connect('localhost','root','ifsp');
	if (!$db){
		die("falha na conexão ao BD");
	}
	mysqli_select_db($db,'bd_querodoar');
	$sql = "SELECT email, senha, nome 
	FROM tb_entidade
	WHERE email = '$email' AND senha='$senha'";
	
	$result_id = mysqli_query($db,$sql) or die ("Erro no banco de dados!");
	
	
	$total = mysqli_num_rows($result_id);
	if($total>0){
		
		// REFATORAR CODIGO 
		while ($row = mysqli_fetch_row($result_id)) {
			$_SESSION['nome'] = $row[0];
			$_SESSION['email'] = $row[2];
		}
		
	
		
		
		header("location:perfilEntidade.php");
	}else{
		echo "dados inválidos";
	}
	
	
?>