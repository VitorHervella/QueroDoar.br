<?php
$db = mysqli_connect('localhost', 'root','ifsp', "bd_querodoar") or die ("A conexão com o servidor não foi executada com sucesso");
?>