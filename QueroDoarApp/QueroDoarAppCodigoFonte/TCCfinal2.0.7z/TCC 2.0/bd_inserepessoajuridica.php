<?php
	 
	 	 session_start();
	 include "conecta.php";
	
		  // RECEBE VARIAVEIS
		  $nomeEmpresa = $_POST['nomeEmpresa'];
		  $nomeFantasia = $_POST['nomeFantasia'];
		  $ramoEmpresa = $_POST['ramoEmpresa'];
		  
		  
		  $cnpj = $_POST['cnpj'];
		  
		  $inscricaoEstadual = $_POST['inscricaoEstadual'];
		  $inscricaoMunicipal = $_POST['inscricaoMunicipal'];
		  		  
		  
		  $cidade = $_POST['cidade'];
		  $estado = $_POST['estado'];
		  
		  $cep = $_POST['cep'];
		  $endereco = $_POST['endereco'];
		  $bairro = $_POST['bairro'];
		  $numero = $_POST['numero'];
		  $complemento = $_POST['complemento'];
		  $website = $_POST['website'];		
		  
		  $telefone = $_POST['telefone'];
		  $celular = $_POST['celular'];
		  
		  $nomeRepresentante = $_POST['nomeRepresentante'];
		  $cpfRepresentante = $_POST['cpfRepresentante'];
		  $cargoRepresentante = $_POST['cargoRepresentante'];
		  $dataNascimentoRepresentante = $_POST['dataNascimentoRepresentante'];		 
		  
		  $email = $_POST['email'];
		  $senha = $_POST['senha'];
		  $repetirSenha = $_POST['repetirSenha'];
		  
		  
		  
		  if (!$nomeEmpresa || !$nomeFantasia || !$ramoEmpresa  || !$cnpj || !$inscricaoEstadual || !$inscricaoMunicipal
		  || !$cidade || !$estado ||  !$cep  || !$endereco || !$bairro || !$numero || !$complemento || !$website || !$telefone || !$celular || !$nomeRepresentante || !$cpfRepresentante || !$cargoRepresentante 
		  || !$dataNascimentoRepresentante  ||!$email || !$senha || !$repetirSenha)
		  {
			 
			 header("location:cadastropessoajuridica.php");
			 echo  "<script>alert('Você nao preencheu todos os campos!!');</script>";
			
			 exit;
		  }
		  
		  //inserindo dados do formulario no bd
		  if($senha == $repetirSenha){
		  $query = "insert into tb_pessoajuridica values (null,'$nomeEmpresa', '$nomeFantasia', '$ramoEmpresa','$cnpj',' $inscricaoEstadual',' $inscricaoMunicipal',
		  '$cidade', '$estado', '$cep','$bairro', '$endereco', '$numero', '$complemento','$website','$telefone', '$celular',
		  '$nomeRepresentante','$cpfRepresentante','$cargoRepresentante',$dataNascimentoRepresentante ,'$email', '$senha', null)";
		 
		  $result = mysqli_query($db,$query);
		  if ($result)
			  
			 $_SESSION['nomeRepresentante'] = $_POST['nomeRepresentante'];
			 $_SESSION['email'] = $_POST['email'];
			 
			 header("location:perfilBeneficiario.php");
			 
		  }else{
			 echo "<script>alert('Ambas as senhas devem ser iguais!!');</script>";
			 echo mysqli_error($db).'<br>';
		  }
	
?>