drop database bd_querodoar;
create database bd_querodoar;
use bd_querodoar;

create table tb_pessoafisica (
id_pf int PRIMARY KEY AUTO_INCREMENT NOT NULL,
nome varchar(100) NOT NULL,
dataNascimento varchar(10) NOT NULL,
sexo varchar(15) NOT NULL,

rg varchar(12) NOT NULL,
cpf varchar(14) NOT NULL,

cidade varchar(50) NOT NULL,
estado varchar(2) NOT NULL,
cep varchar(9) NOT NULL,
bairro varchar(25) NOT NULL,
endereco varchar(50) NOT NULL,
numero int NOT NULL,
complemento varchar(50),

telefone varchar(14),
celular varchar(13) NOT NULL,

email varchar(50) NOT NULL,
senha varchar(100) NOT NULL,
dataCadastro datetime
);

create table tb_pessoajuridica (
id_pf int PRIMARY KEY AUTO_INCREMENT NOT NULL,
nomeEmpresa varchar(100) NOT NULL,
nomeFantasia varchar(100) NOT NULL,
ramoEmpresa varchar(50) NOT NULL,

cnpf varchar(18) NOT NULL,

inscriçãoEstadual varchar(15) NOT NULL,
inscriçãoMunicipal varchar(15) NOT NULL,

cidade varchar(50) NOT NULL,
estado varchar(2) NOT NULL,
cep varchar(9) NOT NULL,
bairro varchar(25) NOT NULL,
endereco varchar(50) NOT NULL,
numero int NOT NULL,
complemento varchar(50),

website varchar(50) NOT NULL,

telefone varchar(14),
celular varchar(13) NOT NULL,

nomeRepresentante varchar(100)NOT NULL,
cpfRepresentante varchar(14)NOT NULL,
cargoRepresentante varchar(20)NOT NULL,
dataNascimentoRepresentante varchar(10)NOT NULL,

email varchar(50) NOT NULL,
senha varchar(100) NOT NULL,
dataCadastro datetime
);

create table tb_entidade (

id_pf int PRIMARY KEY AUTO_INCREMENT NOT NULL,
nomeEntidade varchar(100) NOT NULL,
nomeFantasia varchar(100) NOT NULL,
ramoEntidade varchar(50) NOT NULL,

cnpf varchar(18) NOT NULL,

inscriçãoEstadual varchar(15) NOT NULL,
inscriçãoMunicipal varchar(15) NOT NULL,

cidade varchar(50) NOT NULL,
estado varchar(2) NOT NULL,
cep varchar(9) NOT NULL,
bairro varchar(25) NOT NULL,
endereco varchar(50) NOT NULL,
numero int NOT NULL,
complemento varchar(50),

website varchar(50) NOT NULL,

telefone varchar(14),
celular varchar(13) NOT NULL,

nomeRepresentante varchar(100)NOT NULL,
cpfRepresentante varchar(14)NOT NULL,
cargoRepresentante varchar(20)NOT NULL,
dataNascimentoRepresentante varchar(10)NOT NULL,

email varchar(50) NOT NULL,
senha varchar(100) NOT NULL,
dataCadastro datetime
);
create table tb_prest_serviço (
id_pf int PRIMARY KEY AUTO_INCREMENT NOT NULL,
nome varchar(100) NOT NULL,
dataNascimento varchar(10) NOT NULL,
sexo varchar(15) NOT NULL,
rg varchar(12) NOT NULL,
cpf varchar(14) NOT NULL,
profissao varchar(25)NOT NULL,
ramoServiço varchar(50)NOT NULL,
descricaoAtividade varchar(500)NOT NULL,

cnpf varchar(18) NOT NULL,
inscriçãoEstadual varchar(15) NOT NULL,
inscriçãoMunicipal varchar(15) NOT NULL,

website varchar(50),

cidade varchar(50) NOT NULL,
estado varchar(2) NOT NULL,
cep varchar(9) NOT NULL,
bairro varchar(25) NOT NULL,
endereco varchar(50) NOT NULL,
numero int NOT NULL,
complemento varchar(50),

telefone varchar(14),
celular varchar(13) NOT NULL,

email varchar(50) NOT NULL,
senha varchar(100) NOT NULL,
dataCadastro datetime
);



