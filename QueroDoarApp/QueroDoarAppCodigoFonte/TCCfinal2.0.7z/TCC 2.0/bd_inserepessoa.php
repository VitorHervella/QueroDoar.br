﻿<?php
	 session_start(); 
	 	
	 
	 
	 include "conecta.php";
	
		  // RECEBE VARIAVEIS
		  $nome = $_POST['nome'];
		  $dataNascimento = $_POST['dataNascimento'];
		  $sexo = $_POST['sexo'];
		  
		 
		  $rg = $_POST['rg'];
		  $cpf = $_POST['cpf'];
		  
		  $cidade = $_POST['cidade'];
		  $estado = $_POST['estado'];
		  
		  $cep = $_POST['cep'];
		  $endereco = $_POST['endereco'];
		  $bairro = $_POST['bairro'];
		  $numero = $_POST['numero'];
		  $complemento = $_POST['complemento'];
		 
		 
		  $telefone = $_POST['telefone'];
		  $celular = $_POST['celular'];
		  
		  $email = $_POST['email'];
		  $senha = $_POST['senha'];
		  $repetirSenha = $_POST['repetirSenha'];
		  
		  
		/*  echo "
			function valida(){
				if(document.getElementById('nome'))
			}
		  ";
		  */
		 if (!$nome || !$dataNascimento || !$sexo  || !$rg || !$cpf || !$cidade || !$estado || !$cep  || !$endereco
		  || !$bairro || !$numero || !$complemento || !$telefone || !$celular|| !$email || !$senha || !$repetirSenha)
		  {			

			 echo"<script>alert('Voce não preencheu todos os dados')</script>";
			 return false;
			 
			
			 exit;
		  }
		  
		  //inserindo dados do formulario no bd
		  if($senha == $repetirSenha){
		  $query = "insert into tb_pessoafisica values (null,'$nome', '$dataNascimento', '$sexo', '$rg', '$cpf', '$cidade', '$estado', '$cep','$bairro', '$endereco', '$numero', '$complemento', '$telefone', '$celular',
		  '$email', '$senha', null)";
		  $result = mysqli_query($db,$query);
		  
		
		  if ($result)		
				//$email = $_POST['email'];
				//$senha = $_POST['senha'];
				
				$_SESSION['nome'] = $_POST['nome'];
				$_SESSION['email'] = $_POST['email'];
				
			  header("location:perfilPessoa.php");
		  
		  }else{
			 echo"<script>alert('Ambas as senhas devem ser iguais')</script>";
			 mysqli_error($db).'<br>';
			
		  }
	
?>