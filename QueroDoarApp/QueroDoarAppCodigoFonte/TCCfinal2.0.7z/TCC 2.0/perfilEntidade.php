<?php
session_start();

$nome  = $_SESSION['email'];
?>
<html>
	<meta charset="utf-8" />
	<body>
	<header>
	<link rel="stylesheet" type="text/css" href="perfilPessoa.css" />
		<table id = "tablet" width="50%!">
			<tr>						
			<td><h1><div class = "button"></div></h1></td>
			<td><h1><div class = "button">Sobre o site</div></h1></td>
			<td><h1><a href ="page.html"><div class = "button">Sair</div></a></h1></td>	
			</tr>
		</table>
	</header>

	<div id = "BARRALATERAL1">
			</br><center><img src="empresa.png"></center>
			<center><h3><?php echo $nome; ?></h3></center></br>
		<center><form action="bd_inserirproduto.php" method="post">
			<input type="text" name="nome" maxlength="30" size="30"/><br/>
			</br><input type="text" name="marca" maxlength="30" size="30"/><br/>
			</br><input type="text" name="quantidade" maxlength="30" size="30"/><br/>
			</br><input type="text" name="fornecedor" maxlength="30" size="30"/><br/>
		</form></center>
	</div> 
	<div id = "BARRALATERAL2">
	
	</div> 
</body>
</html>