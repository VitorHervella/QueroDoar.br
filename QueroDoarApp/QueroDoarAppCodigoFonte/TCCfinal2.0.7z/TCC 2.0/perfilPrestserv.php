<?php
session_start();

$email  = $_SESSION['nome'];
$nome  = $_SESSION['email'];
?>

<html>
	<meta charset="utf-8" />
	<body>
	<header>
	<link rel="stylesheet" type="text/css" href="perfilPrestserv.css" />
		<table id = "tablet" width="50%!">
			<h4>Prestador de Serviço</h4>
			<tr>						
			<td><h1><div class = "button"></div></h1></td>
			<td><h1><div class = "button">Sobre o site</div></h1></td>
			<td><h1><a href ="page.html"><div class = "button">Sign Out</div></a></h1></td>	
			</tr>
		</table>
	</header>

	<div id = "BARRALATERAL1">
			</br><center><img src="prestserv.png"></center>
			<center><h3><?php echo $nome; ?></h3></center></br>
			<center><h3><?php echo $email; ?></h3></center></br>

	</div> 
	<div id = "BARRALATERAL2">
	
	</div> 
</body>
</html>